# c_hello_world

A simple hello world program in C using autotools.
Useful to remember basic autotools details and used for testing purposes
for other software packages.
