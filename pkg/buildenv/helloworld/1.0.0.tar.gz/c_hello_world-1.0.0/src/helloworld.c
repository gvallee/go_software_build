#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    fprintf(stderr, "Hello world!\n");
}